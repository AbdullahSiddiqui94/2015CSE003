<html>
<title>Presidency University</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Raleway'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php include('session.php'); 
        
     if(!$rowsec['role']=="USER")
     {
         header("location:index.php"); 
     }
     $email=$_SESSION['email'];
    ?>
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
 
</style>
   <header><div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide">Presidency University</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
        <a href="profile.php" class="w3-bar-item w3-button"><i class="fa fa-user "></i><?php echo $email;?></a>
      <a href="update_profile.php" class="w3-bar-item w3-button"><i class="fa fa-pencil"></i> Update</a>
        <a href="student.php" class="w3-bar-item w3-button"> Back</a>
        <a href="logout.php" class="w3-bar-item w3-button"> Logout</a>
      </div></div></div></header>   
<body class="w3-light-grey">
    <br><br>


<div class="w3-content w3-margin-top" style="max-width:1400px;">

  
  <div class="w3-row-padding">
  
  


    
      <div class="w3-container w3-card w3-white w3-margin-bottom">
        <h2 class="w3-text-grey w3-padding-16">Updation of your company</h2>
          <?php
          $sql1="SELECT * FROM approve where email='$email'";
    $result1=mysqli_query($con,$sql1);
    $row1=mysqli_fetch_array($result1);
          
        echo'<div class="w3-container">';
          echo"<h5 class='w3-opacity'><b>$row1[4]</b></h5>";
          echo'<h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Jan 2015 (date) <span class="w3-tag w3-teal w3-round">New update</span></h6>';
          echo'<p>Lorem ipsum dolor sit amet. Praesentium magnam consectetur vel in deserunt aspernatur est reprehenderit sunt hic. Nulla tempora soluta ea et odio, unde doloremque repellendus iure, iste.</p>';
          echo'<hr>';
        echo'</div>';
                  echo'<div class="w3-container">';
          echo"<h5 class='w3-opacity'><b>$row1[5]</b></h5>";
          echo'<h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Jan 2015 (date) <span class="w3-tag w3-teal w3-round">New update</span></h6>';
          echo'<p>Lorem ipsum dolor sit amet. Praesentium magnam consectetur vel in deserunt aspernatur est reprehenderit sunt hic. Nulla tempora soluta ea et odio, unde doloremque repellendus iure, iste.</p>';
          echo'<hr>';
        echo'</div>';
                  echo'<div class="w3-container">';
          echo"<h5 class='w3-opacity'><b>$row1[6]</b></h5>";
          echo'<h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Jan 2015 (date) <span class="w3-tag w3-teal w3-round">New update</span></h6>';
          echo'<p>Lorem ipsum dolor sit amet. Praesentium magnam consectetur vel in deserunt aspernatur est reprehenderit sunt hic. Nulla tempora soluta ea et odio, unde doloremque repellendus iure, iste.</p>';
          echo'<hr>';
        echo'</div>';?>
      </div>

     
    
    </div>
    

  </div>
     
    
</div>

<footer class="w3-center w3-black w3-padding-16">
  <p>Powered by <a href="#" title="W3.CSS" target="_blank" class="w3-hover-text-green">abdullah</a></p>
</footer>

</body>
</html>
