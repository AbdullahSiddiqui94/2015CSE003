<!DOCTYPE html>
<html>
<title>Presidency University</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style><?php include('session.php'); 
        
     if(!$rowsec['role']=="ADMIN")
     {
         header("location:index.php"); 
     }
     $email=$_SESSION['email'];
    ?>
body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
     <header><div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide">Presidency University</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
        <a href="admin.php"  class="w3-bar-item w3-button"><i class="fa fa-user "></i><?php echo $email;?></a>
      <a href="find.php"class="w3-bar-item w3-button"> Find aviable students</a>
        <a href="approve.php" class="w3-bar-item w3-button"> Approve</a>
        <a href="admin.php" class="w3-bar-item w3-button"> Back</a>
        <a href="logout.php" class="w3-bar-item w3-button"> Logout</a>
      </div></div></div></header>
<body class="w3-light-grey">

<br>    <br>
<div class="w3-content" style="max-width:1400px">


<div class="w3-center">
<div class="w3-col l8 s12">

  <div class="w3-card-4 w3-margin w3-white">
    <div class="w3-container">
      <h3><b>Add Notice</b></h3>
        *Add information and then submit if requried
      <hr>
    </div>

   <form action="update.php" method="POST" id="usrform" enctype="multipart/form-data">
      <h4> Title</h4><input type="text" placeholder="Enter Title" name="title" required>
       <h4> Description</h4><input type="text" placeholder="Enter Description" name="des" required>
       
       <h4> File</h4><input type="file"  name="more" required><br><br>
       <input type="submit" class="w3-button w3-black w3-round-xlarge w3-button w3-light-grey ">
      </form>
      <h4> Information</h4>
      <textarea rows="4" cols="50" name="comment" form="usrform">
      </textarea>
  </div>
  <hr>

</div>
    </div>
</div>

</body>
</html>
