<?php

include('session.php');

$email=$_SESSION['email'];
$sql="SELECT * from register where email='$email'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);

if($_POST['first'])
{
    $first=$_POST['first'];
}
else
{
    $first=$row[0];
}
if($_POST['last'])
{
    $last=$_POST['last'];
}
else
{
    $last=$row[1];
}
if($_POST['dob'])
{
    $dob=$_POST['dob'];
}
else
{
    $dob=$row[3];
}
if($_POST['phone'])
{
    $phone=$_POST['phone'];
}
else
{
    $phone=$row[11];
}
if($_POST['gender']){
    $gender=$_POST['gender'];
}
else{
    $gender=$row[2];
}
if($_POST['ten'])
{
    $tenc=$_POST['ten'];
}
else
{
    $tenc=$row[5];
}
if($_POST['two'])
{
    $twoc=$_POST['two'];
}
else
{
    $twoc=$row[6];
}
if($_POST['engg'])
{
    $enggc=$_POST['engg'];
}
else
{
    $enggc=$row[7];
}
if($_FILES['tenfile']['name']){

$ten=$_FILES['tenfile']['name'];
$tentmp= $_FILES['tenfile']['tmp_name'];
$ten1='10th/' .	basename($_FILES['tenfile']["name"]);
move_uploaded_file($tentmp,$ten1);
}
else{
    $ten1=$row[8];
}
if($_FILES['twofile']['name']){
$two=$_FILES['twofile']['name'];
$twotmp= $_FILES['twofile']['tmp_name'];
$two1='12th/'.	basename($_FILES['twofile']["name"]);
move_uploaded_file($twotmp,$two1);
}
else{
    $two1=$row[9];
}
if($_FILES['enggfile']['name']){
$engg=$_FILES['enggfile']['name'];
$enggtmp= $_FILES['enggfile']['tmp_name'];
$engg1='engg/'.	basename($_FILES['enggfile']["name"]);
move_uploaded_file($enggtmp,$engg1);
}
else{
    $endd1=$row[10];
}
if($_FILES['profilefile']['name']){
$profile=$_FILES['profilefile']['name'];
$profiletmp= $_FILES['profilefile']['tmp_name'];
$profile1='profile/'.	basename($_FILES['profilefile']["name"]);
move_uploaded_file($profiletmp,$profile1);
}
else{
    $profile1=$row[12];
}


$sql1="UPDATE register set firstname='$first',lastname='$last',gender='$gender',dob='$dob',10_cgpa='$tenc',12_cgpa='$twoc',engg_cgpa='$enggc',10_file='$ten1',12_file='$two1',engg_file='$engg1',phone='$phone',profile='$profile1' where email='$email'";
$result1=mysqli_query($con,$sql1);

if($result1)
{
    header("Location:student.php");
}
else
{
    echo("Error description: " . mysqli_error($con));
}

?>