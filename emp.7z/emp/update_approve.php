<?php

    include("config.php");

    if($_GET['approve'])
    {
        $approve=$_GET['approve'];
    }

    $sql="UPDATE approve SET approved='yes' WHERE email='$approve'";
    $result=mysqli_query($con,$sql);

    $sql1="INSERT INTO register (email)values('$approve')";
    $result1=mysqli_query($con,$sql1);


if(($result)&&($result1))
{
    header("Location:admin.php");
}
else
{
    $message = "Counln'd able to updat approve\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');window.location='index.php'</script>";
}

?>