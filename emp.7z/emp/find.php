
<html>
<title>Presidency University</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <?php include('session.php'); 
        
     if(!$rowsec['role']=="ADMIN")
     {
         header("location:index.php"); 
     }
    $email=$_SESSION['email'];
    
    $sql="SELECT * from register";
    $result=mysqli_query($con,$sql);
   
    ?>
<style>
body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
     <header><div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide">Presidency University</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
        <a href="#" class="w3-bar-item w3-button"><i class="fa fa-user "></i><?php echo $email; ?></a>
        
        <a href="add_notice.php" class="w3-bar-item w3-button"> Add notice</a>
        <a href="approve.php" class="w3-bar-item w3-button"> Approve</a>
        <a href="admin.php"class="w3-bar-item w3-button"> Back</a>
        <a href="logout.php" class="w3-bar-item w3-button"> Logout</a>
      </div></div></div></header>
<body class="w3-light-grey">

<br>    <br>
<div class="w3-content" style="max-width:1400px">
    
    <div class="w3-container">
   <h2>Search by</h2><form action="display.php" method="POST">    
        1oth CGPA<input type="radio" class="w3-radio" name="search" value='10_cgpa'>
        12th CGPA<input type="radio" class="w3-radio" name="search" value='12th_CGPA'>
        Enggring CGPA<input type="radio" class="w3-radio" name="search" value='engg_CGPA'><br>
        Greater<input type="radio" class="w3-radio" name="find" value='greater'>
        Lesser<input type="radio" class="w3-radio" name="find" value='lesser'><br>
        <input type="text" class="w3-xlarge w3-border" size="100%" placeholder="Search..." name="searchby" min="0" max="100" ><input type="submit" class="w3-xlarge w3-border"value="Search">
        </form>
  <table class="w3-table-all w3-large">
    <thead>
      <tr class="w3-light-grey">
        <th>Name</th>
        <th>Email</th>
          <th>Gender</th>
          <th>10<sup>th</sup>CGPA</th>
          <th>12<sup>th</sup>CGPA</th>
          <th>Engginering CGPA</th>
      </tr>
    </thead>
      <?php while($row=mysqli_fetch_array($result)){
    echo "<tr>";
      echo "<td>$row[0]</td>";
        echo "<td>$row[4]</td>";
    echo "<td>$row[2]</td>";
        echo "<td>$row[5]</td>";
    echo "<td>$row[6]</td>";
        echo "<td>$row[7]</td>";
    echo "</tr>";
  }?>
  </table>
</div>



</div>

</body>
</html>
