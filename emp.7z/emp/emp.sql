-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2018 at 02:34 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emp`
--

-- --------------------------------------------------------

--
-- Table structure for table `approve`
--

CREATE TABLE `approve` (
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `approved` varchar(5) DEFAULT NULL,
  `company1` varchar(10) DEFAULT NULL,
  `company2` varchar(10) DEFAULT NULL,
  `company3` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approve`
--

INSERT INTO `approve` (`name`, `email`, `password`, `approved`, `company1`, `company2`, `company3`) VALUES
('amman', 'amman@gmail.com', '1258', 'yes', NULL, NULL, NULL),
('abdullad', 'abdullah@gmail.com', '1234', 'yes', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_center`
--

CREATE TABLE `data_center` (
  `firstname` varchar(20) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `10_cgpa` int(5) DEFAULT NULL,
  `12_cgpa` int(5) DEFAULT NULL,
  `engg_cgpa` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hcl`
--

CREATE TABLE `hcl` (
  `firstname` varchar(20) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `10_cgpa` int(5) DEFAULT NULL,
  `12_cgpa` int(5) DEFAULT NULL,
  `engg_cgpa` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hp`
--

CREATE TABLE `hp` (
  `firstname` varchar(20) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `10_cgpa` int(5) DEFAULT NULL,
  `12_cgpa` int(5) DEFAULT NULL,
  `engg_cgpa` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `role` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `role`) VALUES
('abdullah@gmail.com', '1234', 'ADMIN'),
('amman@gmail.com', '1258', 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `title` varchar(20) DEFAULT NULL,
  `information` text,
  `detail` text,
  `file` varchar(50) DEFAULT NULL,
  `admin` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`title`, `information`, `detail`, `file`, `admin`, `date`) VALUES
('This is for test', 'Welcome', '      Welcome to my project', 'notice/right.png', 'abdullah@gmail.com', '2018-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `paytm`
--

CREATE TABLE `paytm` (
  `firstname` varchar(20) DEFAULT NULL,
  `email` varchar(20) NOT NULL,
  `10_cgpa` int(5) DEFAULT NULL,
  `12_cgpa` int(5) DEFAULT NULL,
  `engg_cgpa` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `firstname` varchar(15) DEFAULT NULL,
  `lastname` varchar(15) DEFAULT NULL,
  `gender` varchar(7) DEFAULT NULL,
  `dob` varchar(10) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `10_cgpa` int(5) DEFAULT NULL,
  `12_cgpa` int(5) DEFAULT NULL,
  `engg_cgpa` int(5) DEFAULT NULL,
  `10_file` varchar(50) DEFAULT NULL,
  `12_file` varchar(50) DEFAULT NULL,
  `engg_file` varchar(50) DEFAULT NULL,
  `phone` int(20) DEFAULT NULL,
  `profile` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`firstname`, `lastname`, `gender`, `dob`, `email`, `10_cgpa`, `12_cgpa`, `engg_cgpa`, `10_file`, `12_file`, `engg_file`, `phone`, `profile`) VALUES
('Amman', 'ma', 'Male', '1997-02-05', 'amman@gmail.com', 58, 81, 75, '10th/back.png', '12th/back.png', 'engg/back.png', 985748578, 'back.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
