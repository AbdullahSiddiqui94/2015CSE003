<?php
include("config.php");
session_start();

$email=$_SESSION['email'];
$title=$_POST['title'];
$des=$_POST['des'];
$comment=$_POST['comment'];
$admin=$email;
$date= date("Y-m-d");


$file=$_FILES['more']['name'];
$filetmp= $_FILES['more']['tmp_name'];
$file1='notice/' .	basename($_FILES['more']["name"]);
move_uploaded_file($filetmp,$file1);




$sql="INSERT INTO notice(title,information,detail,file,admin,date) VALUES ('$title','$des','$comment','$file1','$admin','$date')";
$result=mysqli_query($con,$sql);

if($result)
{
    header("Location:admin.php");
}
else
{
    $message = "Counln'd able to updat notice\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');window.location='index.php'</script>";
}

?>
