<html>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>
    <form action="check.php" method="POST">
        
        <b>E-mail id</b>  <input type="email" name="name" placeholder="  Enter your email" class="w3-border w3-round-xxlarge" required><br><br>
        <b>Password</b>   <input type="password" name="pass" placeholder="  Enter your password" class="w3-border w3-round-xxlarge" required><br><br>
        <input type="submit" class="w3-button w3-black w3-round-xlarge w3-button w3-light-grey ">
    
    </form>
    </body>
</html>