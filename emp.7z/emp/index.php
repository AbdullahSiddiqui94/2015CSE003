<html>
<title>Presidency University</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script>function login() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("login").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", "login.php", true);
  xhttp.send();
}
    function Validate() {
        var password = document.getElementById("txtPassword").value;
        var confirmPassword = document.getElementById("txtConfirmPassword").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
    function myFunction() {
    var x = document.getElementById("txtPassword");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
         var y = document.getElementById("txtConfirmPassword");
    if (y.type === "password") {
        y.type = "text";
    } else {
        y.type = "password";
    }
}
    </script>
<style>
body,h1 {font-family: "Raleway", Arial, sans-serif}
h1 {letter-spacing: 6px}
.w3-row-padding img {margin-bottom: 12px}
</style>
    <header><div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide">Presidency University</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
        <a href="#about" class="w3-bar-item w3-button"> About</a>
        <span onclick="login()" class="w3-bar-item w3-button"> login</span>
      <a href="#company" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Companys</a>
      <a href="#contact" class="w3-bar-item w3-button"><i class="fa fa-paper-plane"></i> Register</a>
      </div></div></div></header>
<body>

<!-- !PAGE CONTENT! -->
<div class="w3-content" style="max-width:1500px">

<!-- Header -->
<header class="w3-panel w3-center w3-opacity" style="padding:128px 16px">
    <form action="check.php" method="POST">
    <div id="login">
    <h1>Presidency University</h1>
  <h1 class="w3-xlarge">Welcome for company where you will be placed</h1>
  
    </div>
    </form>
</header>

<!-- Photo Grid -->

  
<!-- End Page Content -->
</div>


<!-- Page content -->
<div class="w3-content w3-padding" style="max-width:1564px">

  <!-- Project Section -->
  <div class="w3-container w3-padding-32" id="company">
    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Information about company</h3>
  </div>

  <div class="w3-row-padding">
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Hp</div>
        <img src="company/HPE.jpg" alt="company" style="width:100%">
          <h3>Hp</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint
      occaecat cupidatat non proident, sun</p>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">HCL</div>
        <img src="company/HCL.jpg" alt="company" style="width:100%">
          <h3>HCl</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint
      occaecat cupidatat non proident, sun</p>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Paytm</div>
        <img src="company/PAYTM.jpg" alt="company" style="width:100%">
          <h3>Paytm</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint
      occaecat cupidatat non proident, sun</p>
      </div>
    </div>
      <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-display-container">
        <div class="w3-display-topleft w3-black w3-padding">Data Center</div>
        <img src="company/DATA.jpg" alt="company" style="width:100%">
          <h3>Data centers</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint
      occaecat cupidatat non proident, sun</p>
      </div>
    </div>
    
  </div>

  <!-- About Section -->
  <div class="w3-container w3-padding-32" id="about">
    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">About</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint
      occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
      laboris nisi ut aliquip ex ea commodo consequat.
    </p>
  </div>

    <h3 class="w3-padding-16 w3-center">Our members</h3>
    
  <div class=" w3-row-padding w3-grayscale ">
    <div class="w3-col l3 m6 w3-margin-bottom">
      <img src="profile/ceo.jpg" alt="Ceo photo" style="width:100%">
      <h3>Abdullah</h3>
      <p class="w3-opacity">Made by</p>
      <p>From presidency university</p>
     
    </div>
      
   
  </div>
    
  <!-- Contact Section -->
  <div class="w3-container w3-padding-32" id="contact">
    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Register</h3>
    <p>Get register in very simply way.</p>
    <form action="register.php" method="POST">
      <input class="w3-input w3-border" type="text" placeholder="Name" required name="name">
      <input class="w3-input w3-section w3-border" type="email" placeholder="Email" required name="user">
      <input class="w3-input w3-section w3-border" type="password" placeholder="Password" required name="pass" id="txtPassword">
      <input class="w3-input w3-section w3-border" type="password" placeholder="Conform Password" id="txtConfirmPassword">
        <input type="checkbox" onclick="myFunction()">Show Password
      <button class="w3-button w3-black w3-section" type="submit" onclick="return Validate()">
     Submit
      </button>
    </form>
  </div>
  

</div>


<footer class="w3-center w3-black w3-padding-16">
  <p>Powered by <a href="#" title="W3.CSS" target="_blank" class="w3-hover-text-green">Abdullah</a></p>
</footer>

</body>
</html>
