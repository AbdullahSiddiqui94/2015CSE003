<?php

include("config.php");

$name = $_POST['name'];
$email = $_POST['user'];
$password = $_POST['pass'];



$sql = "INSERT INTO approve (name,email,password,approved)VALUES ('$name','$email','$password','no')";
$result = mysqli_query($con, $sql);

$sql1 = "INSERT INTO login (username,password,role)VALUES ('$email','$password','USER')";
$result1 = mysqli_query($con, $sql1);


if(($result)&&($result1))
{  
    
header("Location: index.php");
}
else {
  $message = "Couldn't able to update\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');</script>";
}
?>
