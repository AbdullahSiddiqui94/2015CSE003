<?php

include('config.php');
$search=$_POST  ['search'];
$company=$_POST['company'];
$by=$_POST['by'];
$find=$_POST['find'];
$move=0;
if($find=="greater")
{
$sql="Select * from register where $search>='$by'";
$result=mysqli_query($con,$sql);
}
else{
    $sql="Select * from register where $search<='$by'";
$result=mysqli_query($con,$sql);
}

if($company=='hp'){
    
    while($row=mysqli_fetch_array($result)){
    $first=$row[0];
    $email=$row[4];
    $tenc=$row[5];
    $twoc=$row[6];
    $enggring=$row[7];
    $sql2="INSERT INTO hp (firstname,email,10_cgpa,12_cgpa,engg_cgpa)VALUES ('$first','$email','$tenc','$twoc','$enggring')";
    $result2=mysqli_query($con,$sql2);
    $sql3="update approve set company1='hp' where email='$email'";
    $result3=mysqli_query($con,$sql3);
        $move=1;
}}
elseif($company=='hcl'){
    
    while($row=mysqli_fetch_array($result)){
    $first=$row[0];
    $email=$row[4];
    $tenc=$row[5];
    $twoc=$row[6];
    $enggring=$row[7];
    $sql2="INSERT INTO hcl (firstname,email,10_cgpa,12_cgpa,engg_cgpa)VALUES ('$first','$email','$tenc','$twoc','$enggring')";
    $result2=mysqli_query($con,$sql2);
    $sql3="update approve set company1='hcl' where email='$email'";
    $result3=mysqli_query($con,$sql3);
    $move=1;
}}
elseif($company=='paytm'){
    
    while($row=mysqli_fetch_array($result)){
    $first=$row[0];
    $email=$row[4];
    $tenc=$row[5];
    $twoc=$row[6];
    $enggring=$row[7];
    $sql2="INSERT INTO paytm (firstname,email,10_cgpa,12_cgpa,engg_cgpa)VALUES ('$first','$email','$tenc','$twoc','$enggring')";
    $result2=mysqli_query($con,$sql2);
    $sql3="update approve set company1='paytm' where email='$email'";
    $result3=mysqli_query($con,$sql3);
    $move=1;
}}
elseif($company=='data_center'){
    
    while($row=mysqli_fetch_array($result)){
    $first=$row[0];
    $email=$row[4];
    $tenc=$row[5];
    $twoc=$row[6];
    $enggring=$row[7];
    $sql2="INSERT INTO data_center (firstname,email,10_cgpa,12_cgpa,engg_cgpa)VALUES ('$first','$email','$tenc','$twoc','$enggring')";
    $result2=mysqli_query($con,$sql2);
    $sql3="update approve set company1='data_center' where email='$email'";
    $result3=mysqli_query($con,$sql3);
        $move=1;
}}

    if($move==1){
        header("Location:find.php");
    }
else{
    $message = "Counln'd enter to table\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');window.location='index.php'</script>";
}
?>