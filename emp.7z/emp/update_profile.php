<html>
<title>Presidency University</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
  <?php include('session.php'); 
        
     if(!$rowsec['role']=="USER")
     {
         header("location:index.php"); 
     }
     $email=$_SESSION['email'];
    
    
    $sql="SELECT * from register where email='$email' ";
    $result=mysqli_query($con,$sql);
    $row=mysqli_fetch_array($result);
    
    
    ?>
</style>
   <header><div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide">Presidency University</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
        <a href="profile.php" class="w3-bar-item w3-button"><i class="fa fa-user "></i><?php echo $email;?></a>
        
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-pencil"></i> Update</a>
        <a href="student.php" class="w3-bar-item w3-button"> Back</a>
        <a href="logout.php" class="w3-bar-item w3-button"> Logout</a>
      </div></div></div></header>   
<body class="w3-light-grey">
    <br><br>


<div class="w3-content w3-margin-top" style="max-width:1400px;">

  
  <div class="w3-row-padding">
  
    
    
    
      <div class="w3-white w3-text-grey w3-card-4">
        <div class="w3-display-container">
            <div class="w3-center"><h1>Update Profile</h1></div>
       </div>
        <div class="w3-container">
            <form method="POST" action="update_user.php" enctype="multipart/form-data">
            <p>First Name:-       <input type="text" value='<?php echo "$row[0]";?>'name='first' class="w3-border w3-round-xxlarge"></p>
            <p>Last Name:-       <input type="text" value='<?php echo "$row[1]";?>' name='last'class="w3-border w3-round-xxlarge"></p>
            <p>DOB:-       <input type="date" value='<?php echo "$row[3]";?>' name='dob' class="w3-border w3-round-xxlarge"></p>
            <p>Gender:-      Male <input type="radio" value='Male' name='gender' class="w3-border w3-round-xxlarge">Female<input type="radio" value='female' name='gender' class="w3-border w3-round-xxlarge"></p>
            <p>Phone:-       <input type="text" value='<?php echo "$row[11]";?>' name='phone'class="w3-border w3-round-xxlarge"></p>
            <p>10th percentage:-       <input type="text" value='<?php echo "$row[5]";?>' name='ten' class="w3-border w3-round-xxlarge" min='0' max='100'></p>
            <p>12th percentage:-       <input type="text" value='<?php echo "$row[6]";?>' name='two'class="w3-border w3-round-xxlarge"  min='0' max='100'></p>
            <p>Enggering percentage:-       <input type="text" value='<?php echo "$row[7]";?>'  name='engg'class="w3-border w3-round-xxlarge"  min='0' max='100'></p>
<p>10th file:-       <input type="file" name='tenfile' class="w3-border w3-round-xxlarge"></p><img src='<?php"$row[8]"?>' alt="10th" width="20%" height="20%">
<p>12th file:-       <input type="file"  name='twofile'class="w3-border w3-round-xxlarge"></p><img src='<?php"$row[9]"?>' alt="12th" width="20%" height="20%">
<p>Enggering file:-       <input type="file"  name='enggfile'class="w3-border w3-round-xxlarge"></p><img src='<?php"$row[10]"?>' alt="Engg" width="20%" height="20%">
<p>Profile:-       <input type="file"  name='profilefile'class="w3-border w3-round-xxlarge"></p><img src='<?php"$row[12]"?>' alt="man" width="20%" height="20%">
          <hr>
            <input type="submit" class="w3-button w3-black w3-round-xlarge w3-button w3-light-grey ">   
           </form> 
           
          
   
    </div>
        </div>
      
    </div>
    
 

  

</div>



</body>
</html>
