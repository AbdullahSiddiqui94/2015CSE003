<?php
	include("config.php");
    session_start();
	$email = $_POST['name'];
	$password = $_POST['pass'];


	$sql = "SELECT * FROM approve WHERE email = '$email'";
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result);
    
    
    $_SESSION['email']=$email;
if($row['approved']=="no"){
	$message = "Not approved yet\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');window.location='index.php'</script>";
 
}
elseif($row['approved']=="yes"){

	$sql1 = "SELECT * FROM login WHERE username = '$email' and password = '$password'";
	$result1 = mysqli_query($con,$sql1);
	$row1 = mysqli_fetch_array($result1);
    if($row1['role']=="USER"){
        
        header("Location:student.php");
    }
    elseif($row1['role']=="ADMIN"){
        
        header("Location:admin.php");
    }
    else{
        $message = "Worng password\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');window.location='index.php'</script>";
        
    }

}




?>
