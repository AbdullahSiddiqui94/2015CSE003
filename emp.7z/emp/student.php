<html>
<title>Presidency University</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?php include('session.php'); 
        
     if(!$rowsec['role']=="USER")
     {
         header("location:index.php"); 
     }
     $email=$_SESSION['email'];
    
    
    $sql="SELECT * from notice";
    $result=mysqli_query($con,$sql);
    
    
    ?>
<style>
body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
   <header><div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide">Presidency University</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
        <a href="profile.php" class="w3-bar-item w3-button"><i class="fa fa-user "></i><?php echo $email;?></a>
        <a href="notification.php" class="w3-bar-item w3-button"><span class="w3-badge w3-right w3-small w3-grey">check</span><i class="fa fa-bell"></i> Notification</a>
      <a href="update_profile.php" class="w3-bar-item w3-button"><i class="fa fa-pencil"></i> Update</a>
        <a href="logout.php" class="w3-bar-item w3-button"> Logout</a>
      </div></div></div></header>
<body class="w3-light-grey">
    


<div class="w3-content" style="max-width:1400px">


<header class="w3-container w3-center w3-padding-32"> 
    <h1><b>A</b> A R</h1>
</header>


<div class="w3-row">


<div class="w3-col l8 s12">

  <?php while($row=mysqli_fetch_array($result)){ 
  echo" <div class='w3-card-4 w3-margin w3-white'>";
    echo" <div class='w3-container'>";
      echo" <h3><b>$row[0]</b></h3>";
      echo" <h5>$row[1], <span class='w3-opacity'>$row[5]</span></h5>";
    echo" </div>";

    echo" <div class='w3-container'>";
      echo" <p>$row[2]</p>";
      echo" <div class='w3-row'>";
        echo" <div class='w3-col m8 s12'>";
    echo "BY:-<span class='w3-opacity'>$row[4]</span></h5>";

          echo" <p><a href='$row[3]' class='w3-button w3-padding-large w3-white w3-border'><b>See file »</b></a></p>";
        echo" </div>";
        echo" <div class='w3-col m4 w3-hide-small'>";
        echo" </div>";
      echo" </div>";
    echo" </div>";
  echo" </div>";
  echo" <hr>";} ?>
</div>


<div class="w3-col l4">
  
  
  <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
      <h4>Company's you got selected</h4>
    </div>
    <ul class="w3-ul w3-hoverable w3-white">
        <?php
        $sql1="SELECT * FROM approve where email='$email'";
    $result1=mysqli_query($con,$sql1);
    $row1=mysqli_fetch_array($result1);
        if($row[4]){
      echo '<li class="w3-padding-16">';
        echo "<span class='w3-large'>$row[4]</span><br>";
        echo '<span>Sed mattis nunc</span>';
      echo '</li> ';}
        if($row[5]){
      echo '<li class="w3-padding-16">';
        echo "<span class='w3-large'>$row[5]</span><br>";
        echo '<span>Sed mattis nunc</span>';
      echo '</li> ';}
        if($row[6]){
      echo '<li class="w3-padding-16">';
        echo "<span class='w3-large'>$row[6]</span><br>";
        echo '<span>Sed mattis nunc</span>';
      echo '</li> ';}?>
      
    </ul>
  </div>
  <hr>
  
  <!-- companys -->
    <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
      <h4>Company</h4>
    </div>
    <ul class="w3-ul w3-hoverable w3-white">
      <li class="w3-padding-16">
        <img src="company/HPE.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">HP</span><br>
        <span>Sed mattis nunc</span>
      </li>
      <li class="w3-padding-16">
        <img src="company/HCL.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">Hcl</span><br>
        <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Praes tinci sed</span>
      </li> 
      <li class="w3-padding-16">
        <img src="company/PAYTM.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">Paytm</span><br>
        <span>Ultricies congue</span>
      </li>   
      <li class="w3-padding-16 w3-hide-medium w3-hide-small">
        <img src="company/DATA.jpg" alt="Image" class="w3-left w3-margin-right" style="width:50px">
        <span class="w3-large">Data Center</span><br>
        <span>Lorem ipsum dipsum</span>
      </li>  
    </ul>
  </div>
  <hr> 
 


</div>


</div><br>


</div>


<footer class="w3-center w3-black w3-padding-16">
  <p>Powered by <a href="#" title="W3.CSS" target="_blank" class="w3-hover-text-green">Abdullah</a></p>
</footer>

</body>
</html>
